package maven;

/**
 * @author georgi.hristov@clouway.com
 */
public class Messages {

  public String onSuccess(){
    return "SUCCESSFULLY BUILT!!!";
  }

}
