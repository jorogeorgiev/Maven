package maven;

/**
 * @author georgi.hristov@clouway.com
 */
public interface StatusLogger {

  public void log(String msg);

}
